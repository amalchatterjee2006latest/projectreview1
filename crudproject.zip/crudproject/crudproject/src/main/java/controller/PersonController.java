package controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import model.MyUser;
import model.Person;
//import model.Productdisplay;
import model.userlocation;

import dao.PersonDAOImpl;
import dao.PersonServiceImpl;
 
@Controller
public class PersonController 
{
     @Autowired
     private PersonServiceImpl personService1;
    
    

    //GO TO ABOUT.JSP     
     @RequestMapping("/about")
     public String about() 
     {
     return "about";
     }
     
     //for user form
     
     @RequestMapping("/userform")
     public String userform() 
     {
     return "user";
     }
     
    // @RequestMapping("/confirm")
     @RequestMapping(value="/confirm", method = RequestMethod.GET)
     public String confirm() 
     {
     return "confirm";
     }
     
     //GO TO FEEDBACK.JSP
     
     @RequestMapping("/feedback")
     public String feedback() 
     {
       return "feedback";
     }
     
     
     //GO TO  CONTACT.JSP
     @RequestMapping("/contact")
     public String contact() 
     {
       return "contact";
     }
     
   //GO TO  terms.JSP
     @RequestMapping("/terms")
     public String terms() 
     {
       return "terms";
     }
     
     
     //GO TO NDEX.HTML
     
     @RequestMapping("/")
     public String indexpage() 
     {
       return "index";
     }
    
 //GO TO NDEX.HTML
     
     @RequestMapping("/home")
     public String indexpage1() 
     {
       return "index";
     }
  
 
  
     // GO TO LOGIN.JSP
   
    @RequestMapping("/login")
	 public String showHome1()
	 {
		return "login";
	 }
   
   //   GO TO ERROR.JSP
   @RequestMapping("/error")
	public String showHome3()
	{
		return "error";
	}
   
	//for sale confirmation
   
   @RequestMapping(value="/sale", method = RequestMethod.GET)
  	public String sale()
  	{
  		return "sale";
  	}
   
   
   //go to log out
   
   @RequestMapping("/quit")
   public String quit() 
   {
   return "quit";
   }
   
   
    // GO TO  ADMIN  PAGE FOR  CRUD
    @RequestMapping(value = "/persons", method = RequestMethod.GET)
    public String listPersons(Model model) {
        model.addAttribute("person", new Person());
        model.addAttribute("listPersons", this.personService1.listPersons());
        return "person";
    }
     
    //For add and update   PRODUCTS
    @RequestMapping(value= "/person/add", method = RequestMethod.POST)
    public String addPerson(@ModelAttribute("person") Person p)
    {
         
        if(p.getId() == 0)
        {
            //new PRODUCT, add it
            this.personService1.addPerson(p);
        }
        else
        {
            //for existing product call update
            this.personService1.updatePerson(p);
        }
         
        return "redirect:/persons";
         
     }
     
    // FOR DELETING PRODUCTS  FROM ADMIN LOGIN
    
     @RequestMapping("/remove/{id}")
      public String removePerson(@PathVariable("id") int id)
     {
         
        this.personService1.removePerson(id);
        return "redirect:/persons";
     }
  
      @RequestMapping("/edit/{id}")
      public String editPerson(@PathVariable("id") int id, Model model)
      {
        model.addAttribute("person", this.personService1.search(id));
        model.addAttribute("listPersons", this.personService1.searchAll());
        return "person";
      }
    
      //for display of productdetails  added
    
  /* @RequestMapping("productdetails")
	public ModelAndView showProducts()
	{
		ModelAndView mv=new ModelAndView("productdetails");
		List<Person> employeeList=new ArrayList<Person>();
		employeeList=personService1.listPersons();
		mv.addObject("listfromtab",employeeList);
		return mv;
	}*/
    
    
	@ModelAttribute("myUser")
    public MyUser getLoginForm() 
	{
        return new MyUser();
    }
	
	
	@RequestMapping(value = "/myForm", method = RequestMethod.GET)
    public String showForm(Map model) {
        return "myForm";
    }

    @RequestMapping(value = "/myForm", method = RequestMethod.POST)
    public String validateForm(
        @ModelAttribute("myUser") @Valid MyUser myUser,
        BindingResult result, Map model) 
       {

        if (result.hasErrors())
        {
            return "myForm";
        }
        
       return "sale";

       }
	
      //end of spring validation

    //for display of products for   normal user
	
  	@RequestMapping(value = "/ProductDetails", method = RequestMethod.GET)
       public String listProductforUser(Model model)
   	{
           model.addAttribute("product", new Person());
           model.addAttribute("listProduct", this.personService1.searchAll());
           return "ProductDetails";
       }

   	// end of display of products for   normal user
   	
   	
   	
   	//for display of a selected product
   	
   	@RequestMapping("ProductDetails/{id}")
 	public String getProductDetailsInfo(@PathVariable("id") int id, Model model){
	
 		model.addAttribute("selectedproduct",this.personService1.search(id));
 		return "ProductDetailsInfo";
 	}	
   	
  //for usr add and delete
   	
 
   @RequestMapping(value = "/userdetails", method = RequestMethod.GET)
    public String listuser(Model model) {
        model.addAttribute("user", new userlocation());
        model.addAttribute("listuser", this.personService1.listuser());
       // return "userdetail";
        return "userdetailsvalidation";
    }
     
    //For add and update of user
    @RequestMapping(value= "/userdetail/add", method = RequestMethod.GET)
    public String adduser(@ModelAttribute("user")  @Valid userlocation p,BindingResult result,Map model)
    {
         
        //if(p.getId() == 0)
    	if(result.hasErrors())
        {
    		//return "userdetail";
    		
    		return "userdetailsvalidation";
            //new PRODUCT, add it
            //this.personService1.adduser(p);
        }
        else
        {
            //for existing product call update
            this.personService1.adduser(p);
            
        }
         
       //return "redirect:/userdetails";
       return "redirect:/confirm";
        
        //return "user";
         
     }
  
    @RequestMapping(value = "/ProductDetailsdummy", method = RequestMethod.GET)
    public String listProductforUserdummy(Model model)
	{
        model.addAttribute("product", new Person());
        model.addAttribute("listProduct", this.personService1.searchAll());
        //return "productdisplaylatest";
        return "productdisplaylatestresponsive";
    }
   	
    
  //for cart storage
  	@RequestMapping(value= "/cart", method = RequestMethod.POST)
     public String addcart(@ModelAttribute("cart") Person p, HttpServletRequest request,HttpServletResponse response ) throws ServletException, IOException
      
      {
  		  this.personService1.addcart(request , response);
  		  
  		 // RequestDispatcher r=req.getRequestDispatcher(arg0)
  		  //return "redirect:/persons";
  		 // return "OrderSummary";
  		    return "cart";
      }
  	//---------------------------------------------------------------------
  	
  	
 
  	
  	
  	@RequestMapping(value= "/endprocess", method = RequestMethod.POST)
    public String addconfirm(@ModelAttribute("endprocess") userlocation p, HttpServletRequest request,HttpServletResponse response ) throws ServletException, IOException
     
     {
 		  this.personService1.addconfirm(request, response);
 		  
 		  
 		 // RequestDispatcher r=req.getRequestDispatcher(arg0)
 		  //return "redirect:/persons";
 		 // return "OrderSummary";
 		    return "redirect:/userform";
     }
   	
    
}